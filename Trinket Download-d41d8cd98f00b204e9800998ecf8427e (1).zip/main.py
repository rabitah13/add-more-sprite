import pygame 
import random

pygame.init()

screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("player vs enemies")

WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
RED = (255, 0, 0)

player_size = 50 
player = pygame.Rect(100, 100, player_size, player_size)
player_speed = 5

enemy_size = 50
enemies = []

for i in range(7):
  x = random.randint(0, WIDTH - enemy_size)
  y = random.randint(0, HEIGHT - enemy_size)
  eemies.append(pygame.Rect(x,y, enemy_size, enemy_size))
  
  score = 0
  
  font = pygame.font.sysfont(None , 36)
  
  
  running = True
  clock = pygame.time.clock()
  
  while running:
    clock.tick(60)
    screen.fill(WHITE)
    
    
    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        running = False
    keys = pygame.keyget_pressed()
    
    if keys[pygame k_LEFT]:
      player.x -=player_speed
    if keys[pygame k_RIGHT]:
      player.x +=player_speed
    if keys[pygame k_UP]:
      player.y -=player_speed
    if keys [pygame k_DOWN]:
      player.y +=player_speed
      
    for enemy in enemies[:]:
      if player . colliderect(enemy)
                  score += 
                  enemies.remove (enemy)
                  
         random position
                     x = random.randint(0, WIDTH - enemy_size)
                     y = random.randint(0, HEIGHT - enemy_size)
         enemies.append(pygame.Rect(x, y, enemy_size, enemy_size))
              pygame.draw.rect(screen, BLUE, player)
              
              for enemy in enemies:
                pygame.draw.rect(screen, RED, enemy)
                
              score_text = 
            
        
 font.render("score:" + str(score), True, (0,0,0))
                                   screen.blit(score_text, (10, 10))
                                   pygame.display.update()
pygame.quit()
                                           
                                           
                     
                     
           
      
  
  
  
